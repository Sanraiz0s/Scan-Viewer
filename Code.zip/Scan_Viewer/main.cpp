#include "CursorControl.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    CursorControl cursorControl;
    cursorControl.show();
    return app.exec();
}
