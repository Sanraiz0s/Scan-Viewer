#ifndef CURSORCONTROL_H
#define CURSORCONTROL_H

#include <QMainWindow>
#include <QImage>

#include <vector>
#include <memory>
#include <cstdint>

QT_BEGIN_NAMESPACE
namespace Ui {
class CursorControl;
}
QT_END_NAMESPACE

class BScanViewer;

class CursorControl : public QMainWindow
{
    Q_OBJECT

public:
    explicit CursorControl(QWidget *parent = nullptr);
    ~CursorControl();

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void fooOpenButton();
    void onSliderValueChanged();
    void processData();
    void onLimit7000Toggled (bool on);
    void setIsReadFile();

private:
    Ui::CursorControl *ui;
    std::unique_ptr<BScanViewer> bScan;

    std::vector<std::vector<std::vector<int>>> resultData;

    bool isReadFile = false;

    int globalMin = 0;
    int globalMax = 1;

    bool limitTo7000 = false;
    void updateTextButton();

    bool parseBinFile(const QString &filePath);
    void posWindows();
    void calcResultData (
            std::vector<std::vector<std::vector<int16_t>>> &part0,
            std::vector<std::vector<std::vector<int16_t>>> &part1
    );
    QImage makeBScanPic(int txIndex, int ampMax);
    static QColor colorFromRatio(float ratio);
};

#endif // CURSORCONTROL_H
