#include "CursorControl.h"
#include "ui_CursorControl.h"
#include "BScanViewer.h"

#include <QFileDialog>
#include <QFile>
#include <QMessageBox>
#include <QIcon>
#include <QColor>
#include <QCloseEvent>
#include <QTimer>
#include <QGuiApplication>
#include <QScreen>
#include <QApplication>

#include <cmath>
#include <algorithm>

CursorControl::CursorControl(QWidget *parent):
    QMainWindow(parent),
    ui(new Ui::CursorControl),
    bScan(std::make_unique<BScanViewer>())
{
    ui->setupUi(this);
    setWindowTitle("Cursor control");
    setWindowIcon(QIcon(":/resources/resources/math.png"));
    ui->Slider->setRange(0, 63);
    ui->ShowNum->setText("0");

    connect(ui->BLoadFile, &QPushButton::clicked, this, &CursorControl::fooOpenButton);
    connect(ui->Slider, &QSlider::valueChanged, this, &CursorControl::onSliderValueChanged);

    qApp->setQuitOnLastWindowClosed(false);

    bScan->show();
    QTimer::singleShot(0, this, &CursorControl::posWindows);
}

CursorControl::~CursorControl()
{
    delete ui;
}

void CursorControl::closeEvent(QCloseEvent *event)
{
    event->accept();
    qApp->quit();
}

void CursorControl::posWindows()
{
    QScreen *screen = QGuiApplication::primaryScreen();
    if (!screen) return;

    const QRect avail = screen->availableGeometry();

    const QSize ccSize = frameGeometry().size();
    const QSize bsSize = bScan ? bScan->frameGeometry().size() : QSize(640, 480);

    const int gap = 20;

    const int centerX = avail.center().x();
    const int centerY = avail.center().y();

    const QPoint ccPos(centerX - gap / 2 - ccSize.width(), centerY - ccSize.height() / 2);
    const QPoint bsPos(centerX + gap / 2, centerY - bsSize.height() / 2);

    move(ccPos);
    if (bScan) bScan->move(bsPos);
}

void CursorControl::fooOpenButton()
{
    QString filePath = QFileDialog::getOpenFileName(this,
                                                    "Откройте файл для чтения",
                                                    "",
                                                    "Binary Files (*.bin *.binary);;All Files(.)");

    if (filePath.isEmpty()) return;
    if (parseBinFile(filePath))
    {
        processData();
    }
}

void CursorControl::onSliderValueChanged()
{
    processData();
}

bool CursorControl::parseBinFile(const QString &filePath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox mBox(this);
        mBox.setWindowTitle("Error!");
        mBox.setText("Не удалось открыть файл");
        mBox.setIconPixmap(QPixmap(":/resources/resources/error.png"));
        mBox.exec();
        return false;
    }

    QByteArray data = file.readAll();
    file.close();

    const size_t expSize = 2 * 64 * 64 * 8192 * sizeof(int16_t);
    if (static_cast<size_t>(data.size()) != expSize)
    {
        QMessageBox mBox(this);
        mBox.setWindowTitle("Error!");
        mBox.setText(QString("Размер файла не соответствует ожидаемым данным").arg(expSize).arg(data.size()));
        mBox.setIconPixmap(QPixmap(":/resources/resources/error.png"));
        mBox.exec();

        return false;
    }

    const int16_t *dptr = reinterpret_cast<const int16_t*> (data.constData());

    std::vector<std::vector<std::vector<int16_t>>> part0(64);
    size_t index = 0;
    for (int tx = 0; tx < 64; ++tx)
    {
        part0[tx].resize(64);
        for (int rx = 0; rx < 64; ++rx)
        {
            part0[tx][rx].resize(8192);
            for (int sample = 0; sample < 8192; ++sample)
            {
                part0[tx][rx][sample] = dptr[index++];
            }
        }
    }

    std::vector<std::vector<std::vector<int16_t>>> part1(64);
    for (int tx = 0; tx < 64; ++tx)
    {
        part1[tx].resize(64);
        for (int rx = 0; rx < 64; ++rx)
        {
            part1[tx][rx].resize(8192);
            for (int sample = 0; sample < 8192; ++sample)
            {
                part1[tx][rx][sample] = dptr[index++];
            }
        }
    }

    calcResultData(part0, part1);
    return true;
}

void CursorControl::calcResultData(
    std::vector<std::vector<std::vector<int16_t>>> &part0,
    std::vector<std::vector<std::vector<int16_t>>> &part1)
{
    resultData.resize(64);
    globalMin = INT16_MAX;
    globalMax = INT16_MIN;

    for (int tx = 0; tx < 64; ++tx)
    {
        resultData[tx].resize(64);
        for (int rx = 0; rx < 64; ++rx)
        {
            resultData[tx][rx].resize(8192);
            for (int sample = 0; sample < 8192; ++sample)
            {
                int num0 = part0[tx][rx][sample];
                int num1 = part1[tx][rx][sample];
                int res = static_cast<int>(std::lround(std::sqrt(static_cast<float>(num0) * num0 + static_cast<float>(num1) * num1)));
                resultData[tx][rx][sample] = res;
                globalMin = std::min(globalMin, res);
                globalMax = std::max(globalMax, res);
            }
        }
    }
}

void CursorControl::processData()
{
    if (bScan)
    {
        int sliderValue = ui->Slider->value();
        ui->ShowNum->setText(QString::number(sliderValue));

        QImage BScanPic = makeBScanPic(sliderValue);
        bScan->updatePic(BScanPic);
        bScan->setTxIndex(sliderValue);
    }
}

QColor CursorControl::colorFromRatio(float ratio)
{
    ratio = std::clamp(ratio, 0.0f, 1.0f);
    ratio = ratio * ratio * (3.0f - 2.0f * ratio);
    ratio = std::pow(ratio, 0.8f);

    auto lerp = [] (float a, float b, float t)
    {
        return a + (b - a) * t;
    };

    struct Stop
    {
        float p, r, g, b;
    };

    static const Stop stops[] = {
        {0.00f, 0.0f, 0.0f, 1.0f},
        {0.25f, 0.0f, 1.0f, 1.0f},
        {0.50f, 0.0f, 1.0f, 0.0f},
        {0.75f, 1.0f, 1.0f, 0.0f},
        {1.00f, 1.0f, 0.0f, 0.0f}
    };

    int idx = 0;
    while (idx + 1 <static_cast<int>(std::size(stops)) && ratio > stops[idx + 1].p) ++idx;

    const Stop& a = stops[idx];
    const Stop& b = stops[std::min(idx + 1, static_cast<int>(std::size(stops)) - 1)];

    float t = (b.p > a.p) ? (ratio - a.p) / (b.p - a.p) : 0.0f;

    float r = lerp(a.r, b.r, t);
    float g = lerp(a.g, b.g, t);
    float bl = lerp(a.b, b.b, t);

    return QColor::fromRgbF(r, g, bl);
}

QImage CursorControl::makeBScanPic(int txIndex)
{
    const int width = 64;
    const int height = 8192;   

    QImage img(width, height, QImage::Format_RGB888);

    if (resultData.empty())
    {
        img.fill(Qt::black);
        return img;
    }

    const int min = globalMin;
    const int max = globalMax;

    if (max <= min)
    {
        img.fill(Qt::black);
        return img;
    }

    const float range = static_cast<float>(max - min);

    for (int rx = 0; rx < width; ++rx)
    {
        const auto& samples = resultData[txIndex][rx];
        for (int y = 0; y < height; ++y)
        {
            float ratio = static_cast<float>(samples[y] - static_cast<float>(min)) / range;
            QColor color = colorFromRatio(ratio);
            img.setPixelColor(rx, y, color);
        }
    }
    return img;
}
