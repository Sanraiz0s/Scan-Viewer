#ifndef BSCANVIEWER_H
#define BSCANVIEWER_H

#include <QMainWindow>
#include <QImage>

QT_BEGIN_NAMESPACE
namespace Ui {
class BScanViewer;
}
QT_END_NAMESPACE

class LegendWidget;

class BScanViewer : public QMainWindow
{
    Q_OBJECT

public:
    explicit BScanViewer(QWidget *parent = nullptr);
    ~BScanViewer();

    void updatePic (const QImage &img);
    void setTxIndex(int index);
    void setAmpRange(int minV, int maxV);

protected:
    void closeEvent(QCloseEvent *event) override;

private:
    Ui::BScanViewer *ui;

    int txIndex = 0;
    int ampMin = 0;
    int ampMax = 7000;

    LegendWidget* legendRight = nullptr;

    void updateTitle();
    static QImage makeBar (int width, int height);
};

#endif // BSCANVIEWER_H
