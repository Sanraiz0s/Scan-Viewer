#include "BScanViewer.h"
#include "ui_BScanViewer.h"
#include "LegendWidget.h"

#include <QPixmap>
#include <QColor>
#include <QGridLayout>
#include <QCloseEvent>

#include <cmath>
#include <algorithm>

BScanViewer::BScanViewer(QWidget *parent): QMainWindow(parent), ui(new Ui::BScanViewer)
{
    ui->setupUi(this);
    setWindowIcon(QIcon(":/resources/resources/math.png"));
    setWindowFlags(windowFlags()& ~Qt::WindowCloseButtonHint);
    updateTitle();

    auto* legendLeft = new LegendWidget(this);
    legendLeft->setOrientation(LegendWidget::Orientation::VerticalLeft);
    legendLeft->setRange(0, 8192);
    legendLeft->setTicks({0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000});

    auto* legendBottom = new LegendWidget(this);
    legendBottom->setOrientation(LegendWidget::Orientation::Horizontal);
    legendBottom->setRange(0, 63);
    legendBottom->setTicks({0, 10, 20, 30, 40, 50, 60});

    auto* legendRight = new LegendWidget(this);
    legendRight->setOrientation(LegendWidget::Orientation::VerticalRight);
    legendRight->setRange(0, 7000);
    legendRight->setTicks({0, 1000, 2000, 3000, 4000, 5000, 6000, 7000});

    auto* grid = new QGridLayout(ui->centralwidget);
    grid->setContentsMargins(6, 6, 6, 6);
    grid->setHorizontalSpacing(6);
    grid->setVerticalSpacing(4);

    ui->OutLabel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    ui->LabelBar->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);

    legendLeft->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);
    legendBottom->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    legendRight->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);

    grid->addWidget(legendLeft, 0, 0);
    grid->addWidget(ui->OutLabel, 0, 1);
    grid->addWidget(ui->LabelBar, 0, 2);
    grid->addWidget(legendBottom, 1, 1);
    grid->addWidget(legendRight, 0, 3);

    grid->setColumnStretch(1, 1);
    grid->setColumnStretch(0, 0);
    grid->setColumnStretch(2, 0);
    grid->setColumnStretch(3, 0);
}

BScanViewer::~BScanViewer()
{
    delete ui;
}

void BScanViewer::closeEvent(QCloseEvent *event)
{
    event->ignore();
}

void BScanViewer::setTxIndex(int index)
{
    txIndex = index;
    updateTitle();
}

void BScanViewer::updateTitle()
{
    setWindowTitle(QString("B-scan viewer: TX=%1").arg(txIndex));
}

void BScanViewer::updatePic(const QImage &img)
{
    if (!img.isNull())
    {
        ui->OutLabel->setPixmap(QPixmap::fromImage(img).scaled(ui->OutLabel->size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation));
    }

    QImage colorBar = makeBar(ui->LabelBar->width(), ui->LabelBar->height());
    ui->LabelBar->setPixmap(QPixmap::fromImage(colorBar));
}

QImage BScanViewer::makeBar(int width, int height)
{
    QImage colorBar(width, height, QImage::Format_RGB888);

    auto rgbFromRatio = [](float ratio) ->QColor
    {
        ratio = std::clamp(ratio, 0.0f, 1.0f);
        ratio = ratio * ratio * (3.0f - 2.0f * ratio);
        ratio = std::pow(ratio, 0.8f);

        auto lerp = [] (float a, float b, float t)
        {
            return a + (b - a) * t;
        };

        struct Stop
        {
            float p, r, g, b;
        };

        static const Stop stops[] = {
            {0.00f, 0.0f, 0.0f, 1.0f},
            {0.25f, 0.0f, 1.0f, 1.0f},
            {0.50f, 0.0f, 1.0f, 0.0f},
            {0.75f, 1.0f, 1.0f, 0.0f},
            {1.00f, 1.0f, 0.0f, 0.0f}
        };

        int idx = 0;
        while (idx + 1 <static_cast<int>(std::size(stops)) && ratio > stops[idx + 1].p) ++idx;

        const Stop& a = stops[idx];
        const Stop& b = stops[std::min(idx + 1, static_cast<int>(std::size(stops)) - 1)];

        float t = (b.p > a.p) ? (ratio - a.p) / (b.p - a.p) : 0.0f;

        float r = lerp(a.r, b.r, t);
        float g = lerp(a.g, b.g, t);
        float bl = lerp(a.b, b.b, t);

        return QColor::fromRgbF(r, g, bl);
    };

    for (int y = 0; y < height; ++y)
    {
        float t = (height == 1) ? 0.0f : static_cast<float>(y) / static_cast<float>(height - 1);
        QColor color = rgbFromRatio(t);

        for (int x = 0; x < width; ++x)
        {
            colorBar.setPixelColor(x, height - y - 1, color);
        }
    }

    return colorBar;
}
