#ifndef LEGENDWIDGET_H
#define LEGENDWIDGET_H

#include <QWidget>

class LegendWidget: public QWidget
{
    Q_OBJECT

public:
    enum class Orientation {Horizontal, VerticalLeft, VerticalRight};

    explicit LegendWidget(QWidget *parent = nullptr);

    void setOrientation(Orientation o);
    void setRange(float min, float max);
    void setTicks(const QList<float> &ticks);
    void setTicksLabels(const QStringList &labels);
    void setPadding(int px);

protected:
    void paintEvent(QPaintEvent *pE) override;
    QSize sizeHint() const override;

private:
    Orientation orient = Orientation::Horizontal;
    float min = 0.0f;
    float max = 1.0f;
    QList<float> ticks;
    QStringList labels;
    int padding = 4;

    float norm(float v) const;
};

#endif // LEGENDWIDGET_H
