#include "LegendWidget.h"

#include <QPainter>
#include <QFontMetrics>
#include <QRect>
#include <QtGlobal>

#include <cmath>

LegendWidget::LegendWidget(QWidget *parent): QWidget(parent)
{
    setAttribute(Qt::WA_OpaquePaintEvent, false);
    setAutoFillBackground(false);
}

void LegendWidget::setOrientation(Orientation o)
{
    this->orient = o;
    updateGeometry();
    update();
}

void LegendWidget::setRange(float min, float max)
{
    this->min = min;
    this->max = max;
    update();
}

void LegendWidget::setTicks(const QList<float>& ticks)
{
    this->ticks = ticks;
    updateGeometry();
    update();
}

void LegendWidget::setTicksLabels(const QStringList& labels)
{
    this->labels = labels;
    updateGeometry();
    update();
}

void LegendWidget::setPadding(int px)
{
    this->padding = px;
    updateGeometry();
    update();
}

float LegendWidget::norm(float v) const
{
    if (qFuzzyCompare(this->max, this->min)) return 0.0f;
    return (v - this->min) / (this->max - this->min);
}

QSize LegendWidget::sizeHint() const
{
    QFontMetrics fm(font());

    if (this->orient == Orientation::Horizontal)
    {
        return QSize(200, fm.height() + 2 * this->padding + 6);
    }

    QString longest;
    if (!this->labels.isEmpty())
    {
        for (const auto& s : this->labels)
        {
            if (s.size() > longest.size()) longest = s;
        }
    }

    if (!this->ticks.isEmpty())
    {
        for (float t : this->ticks)
        {
            const QString s = QString::number(static_cast<int>(qRound(t)));
            if (s.size() > longest.size()) longest = s;
        }
    }

    if (longest.isEmpty()) longest = "8000";

    int w = fm.horizontalAdvance(longest) + 2 * this->padding + 8;

    return QSize(w, 200);
}

void LegendWidget::paintEvent(QPaintEvent*)
{
    QPainter p(this);
    p.setRenderHint(QPainter::TextAntialiasing, true);
    p.setPen(palette().color(QPalette::WindowText));

    QFontMetrics fm(font());

    const int w = width();
    const int h = height();

    auto labelFor = [this](int i, float tick)->QString
    {
        if (i >= 0 && i < this->labels.size()) return this->labels[i];
        return QString::number(static_cast<int>(qRound(tick)));
    };

    if (this->orient == Orientation::Horizontal)
    {
        const int padL = 4;
        const int padR = 4;
        const int padTop = 2;
        const int tickLen = 4;

        const int tickY = padTop;
        const int textY = tickY + tickLen + 2;

        for (float t : this->ticks)
        {
            float u = norm(t);
            int x = padL + static_cast<int>(u * static_cast<float>(w - padL - padR));

            p.drawLine(x, tickY, x, tickY + tickLen);

            const QString s = QString::number(static_cast<int>(qRound(t)));
            const QRect br = p.fontMetrics().boundingRect(s);
            const int tx = x - br.width() / 2;

            p.drawText(tx, textY + p.fontMetrics().ascent(), s);
        }

        return;
    }

    const bool isRight = (this->orient == Orientation::VerticalRight);
    const int xTickIn = isRight ? this->padding : (w - this->padding);
    const int xTickOut = isRight ? (this->padding + 4) : (w - this->padding + 4);

    const int xLabelOutLeft = this->padding;
    const int xLabelOutRight = w - this->padding;

    for (int i = 0; i < this->ticks.size(); ++i)
    {
        const float t = this->ticks[i];
        const float u = norm(t);

        const float uDraw = isRight ? (1.0f - u) : u;

        const int y = this->padding + qRound(uDraw * (h - 2 * this->padding));
        p.drawLine(xTickOut, y, xTickIn, y);

        const QString s = labelFor(i, t);
        const int tw = fm.horizontalAdvance(s);
        const int ty = y + fm.ascent() / 2;

        if (isRight)
        {
            p.drawText(xLabelOutRight - tw, ty, s);
        }
        else
        {
            p.drawText(xLabelOutLeft, ty, s);
        }
    }
}
