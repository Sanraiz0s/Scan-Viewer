/********************************************************************************
** Form generated from reading UI file 'CursorControl.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CURSORCONTROL_H
#define UI_CURSORCONTROL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CursorControl
{
public:
    QWidget *CC;
    QSlider *Slider;
    QFrame *frame;
    QPushButton *BLoadFile;
    QLabel *ShowNum;

    void setupUi(QMainWindow *CursorControl)
    {
        if (CursorControl->objectName().isEmpty())
            CursorControl->setObjectName(QString::fromUtf8("CursorControl"));
        CursorControl->resize(441, 125);
        CursorControl->setMinimumSize(QSize(441, 125));
        CursorControl->setMaximumSize(QSize(441, 125));
        CursorControl->setStyleSheet(QString::fromUtf8("QMainWidjet {\n"
"	background-color: rgb(97, 97, 97);\n"
"}\n"
"\n"
"QWidjet {\n"
"	background-color: rgb(97, 97, 97);\n"
"}"));
        CC = new QWidget(CursorControl);
        CC->setObjectName(QString::fromUtf8("CC"));
        QFont font;
        font.setFamily(QString::fromUtf8("Georgia"));
        font.setPointSize(10);
        CC->setFont(font);
        Slider = new QSlider(CC);
        Slider->setObjectName(QString::fromUtf8("Slider"));
        Slider->setGeometry(QRect(30, 80, 301, 21));
        Slider->setMinimumSize(QSize(301, 21));
        Slider->setMaximumSize(QSize(301, 21));
        Slider->setStyleSheet(QString::fromUtf8("QSlider::groove:horizontal {\n"
"	border: 1px solid #999999;\n"
"	height: 20px;\n"
"	border-radius: 9px;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"	width: 12px;\n"
"	border-radius: 6px;\n"
" 	background-color: rgb(208, 139, 0);\n"
"}\n"
"\n"
"QSlider::add-page:qlineargradient {\n"
"	background: rgb(173, 173, 173);\n"
"	border-top-right-radius: 5px;\n"
"	border-bottom-right-radius: 5px;\n"
"	border-top-left-radius: 0px;\n"
"	border-bottom-left-radius: 0px;\n"
"}\n"
"\n"
"QSlider::sub-page:qlineargradient {\n"
"	background: rgb(116, 116, 116);\n"
"	border-top-right-radius: 0px;\n"
"	border-bottom-right-radius: 0px;\n"
"	border-top-left-radius: 5px;\n"
"	border-bottom-left-radius: 5px;\n"
"}"));
        Slider->setMaximum(63);
        Slider->setOrientation(Qt::Horizontal);
        frame = new QFrame(CC);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(0, 0, 441, 131));
        frame->setMinimumSize(QSize(441, 131));
        frame->setMaximumSize(QSize(441, 131));
        frame->setStyleSheet(QString::fromUtf8("QFrame {\n"
"	background-color: rgb(63, 63, 63);\n"
"}"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        BLoadFile = new QPushButton(frame);
        BLoadFile->setObjectName(QString::fromUtf8("BLoadFile"));
        BLoadFile->setGeometry(QRect(80, 20, 281, 41));
        BLoadFile->setMinimumSize(QSize(281, 41));
        BLoadFile->setMaximumSize(QSize(281, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Georgia"));
        font1.setPointSize(14);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setKerning(true);
        BLoadFile->setFont(font1);
        BLoadFile->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-color: rgb(116, 116, 116);\n"
"	color: black;\n"
"	border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(150, 150, 150); \n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(80, 80, 80);\n"
"}"));
        ShowNum = new QLabel(frame);
        ShowNum->setObjectName(QString::fromUtf8("ShowNum"));
        ShowNum->setGeometry(QRect(370, 70, 51, 41));
        ShowNum->setMinimumSize(QSize(51, 41));
        ShowNum->setMaximumSize(QSize(51, 41));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Georgia"));
        font2.setPointSize(12);
        font2.setBold(false);
        ShowNum->setFont(font2);
        ShowNum->setLayoutDirection(Qt::LeftToRight);
        ShowNum->setStyleSheet(QString::fromUtf8("QLabel {\n"
"	background-color: rgb(116, 116, 116);\n"
"	color: black;\n"
"	border-radius: 7px;\n"
"}"));
        ShowNum->setFrameShape(QFrame::NoFrame);
        ShowNum->setTextFormat(Qt::RichText);
        ShowNum->setAlignment(Qt::AlignCenter);
        CursorControl->setCentralWidget(CC);
        frame->raise();
        Slider->raise();

        retranslateUi(CursorControl);

        QMetaObject::connectSlotsByName(CursorControl);
    } // setupUi

    void retranslateUi(QMainWindow *CursorControl)
    {
        CursorControl->setWindowTitle(QCoreApplication::translate("CursorControl", "MainWindow", nullptr));
        BLoadFile->setText(QCoreApplication::translate("CursorControl", "Load .binary\342\200\246", nullptr));
        ShowNum->setText(QCoreApplication::translate("CursorControl", "0", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CursorControl: public Ui_CursorControl {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CURSORCONTROL_H
