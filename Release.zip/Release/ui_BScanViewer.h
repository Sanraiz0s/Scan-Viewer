/********************************************************************************
** Form generated from reading UI file 'BScanViewer.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BSCANVIEWER_H
#define UI_BSCANVIEWER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BScanViewer
{
public:
    QWidget *centralwidget;
    QLabel *LabelBar;
    QLabel *OutLabel;

    void setupUi(QMainWindow *BScanViewer)
    {
        if (BScanViewer->objectName().isEmpty())
            BScanViewer->setObjectName(QString::fromUtf8("BScanViewer"));
        BScanViewer->resize(711, 409);
        BScanViewer->setMinimumSize(QSize(711, 409));
        BScanViewer->setMaximumSize(QSize(711, 409));
        centralwidget = new QWidget(BScanViewer);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        LabelBar = new QLabel(centralwidget);
        LabelBar->setObjectName(QString::fromUtf8("LabelBar"));
        LabelBar->setGeometry(QRect(630, 40, 31, 311));
        LabelBar->setMinimumSize(QSize(31, 0));
        LabelBar->setStyleSheet(QString::fromUtf8("QLabel {\n"
"	background-color: white;\n"
"	border-radius: 15px;\n"
"}"));
        OutLabel = new QLabel(centralwidget);
        OutLabel->setObjectName(QString::fromUtf8("OutLabel"));
        OutLabel->setGeometry(QRect(40, 40, 571, 311));
        OutLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"	background-color: white;\n"
"	border-radius: 15px;\n"
"}"));
        BScanViewer->setCentralWidget(centralwidget);

        retranslateUi(BScanViewer);

        QMetaObject::connectSlotsByName(BScanViewer);
    } // setupUi

    void retranslateUi(QMainWindow *BScanViewer)
    {
        BScanViewer->setWindowTitle(QCoreApplication::translate("BScanViewer", "MainWindow", nullptr));
        LabelBar->setText(QString());
        OutLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class BScanViewer: public Ui_BScanViewer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BSCANVIEWER_H
